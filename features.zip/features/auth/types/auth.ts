export interface AuthData {
  email: string;
  password: string;
  confirmPassword?: string; // Для регистрации
}
