export interface House {
  id: number;
  title: string;
  price: number;
  status: string;
  rooms: number;
  area: string;
  image: string;
}
